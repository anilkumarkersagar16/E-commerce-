first time registering then use name `Admin`, password `admin` and email `admin@gmail.com`.

## How to run

### Run using npm

```bash
npm install
npm start
```